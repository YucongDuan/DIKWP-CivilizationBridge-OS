# Source Ledger

This package references the following public materials for theoretical inspiration, governance boundary and platform design. They are used as sources of design vocabulary and theory, not as final proof that any specific DIKWP claim is already institutionally established.

1. DIKWP Semantic Mathematics Overview — https://www.researchgate.net/publication/389324432_DIKWP_Semantic_Mathematics_Overview
2. DIKWP Collapse Background Mechanism Report — https://www.researchgate.net/publication/403883000_STRATEGIC_REPORT_DIKWP_Collapse_Background_Mechanism_Report
3. DIKWP-ProofLedger OS — https://www.researchgate.net/publication/404699131_DIKWP-ProofLedger_OS_Evidence_Ledger_for_AI_Answers_and_Claims
4. DIKWP SemanticJustice Studio V2 — https://github.com/YucongDuan/DIKWP-SemanticJustice-Studio-V2
5. UNESCO Recommendation on the Ethics of Artificial Intelligence — https://www.unesco.org/en/artificial-intelligence/recommendation-ethics
6. UNESCO Reimagining Our Futures Together — https://www.unesco.org/en/articles/reimagining-our-futures-together-new-social-contract-education
