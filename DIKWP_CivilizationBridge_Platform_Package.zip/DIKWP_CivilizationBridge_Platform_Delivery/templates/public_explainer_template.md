# Public Explainer Template

Start from the audience problem, not from the acronym.

1. What problem are you facing?
2. What data do you actually have?
3. What distinctions matter?
4. What knowledge supports your view?
5. What trade-offs must be considered?
6. What human purpose should guide the action?
7. What evidence would change your mind?
