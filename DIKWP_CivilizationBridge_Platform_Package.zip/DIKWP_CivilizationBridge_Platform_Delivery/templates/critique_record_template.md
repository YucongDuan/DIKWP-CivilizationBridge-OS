# Critique Record

- Critique ID:
- Linked claim / solution:
- Critic role:
- Issue type:
- Severity:
- Critique:
- Evidence / counterexample:
- Proposed repair:
- System response:
- Status: Open / Accepted / Rejected with reason / Resolved / Residual
