# DIKWP Pilot Canvas

- Pilot title:
- Host organization:
- Target group:
- Solution card:
- Baseline problem:
- Intervention:
- Metrics:
- Safeguards:
- Duration:
- Success threshold:
- Kill condition:
- Rollback path:
- Evidence to collect:
- Final adoption decision:
