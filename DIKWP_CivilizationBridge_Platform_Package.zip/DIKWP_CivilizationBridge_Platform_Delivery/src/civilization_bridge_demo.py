import json, time

def score(problem, evidence, risk):
    comprehension = min(95, max(20, 35 + len(problem)//20))
    trust = min(95, max(20, 35 + len(evidence)//18 - (10 if len(risk)>80 else 0)))
    readiness = round(0.30*trust + 0.25*comprehension + 0.20*65 + 0.15*70 + 0.10*80)
    return comprehension, trust, readiness

def build_packet(title, audience, problem, claim, evidence, risk):
    c,t,r = score(problem, evidence, risk)
    return {
        'id':'CB-'+str(int(time.time())),
        'title':title,
        'audience':audience,
        'problem':problem,
        'claim':claim,
        'evidence':evidence,
        'risk':risk,
        'scores':{'comprehension':c,'trust':t,'adoption_readiness':r},
        'dikwp':{
            'D':'sources, observations, examples',
            'I':'distinctions, boundaries, audience confusions',
            'K':'theory, prior work, comparable frameworks',
            'W':'trade-offs, cautions, resistance triggers',
            'P':'human development, dignity, public understanding'
        },
        'kill_condition':'If target audience cannot accurately explain the solution after guided examples, rewrite and downgrade claim.'
    }

if __name__ == '__main__':
    packet = build_packet(
        'DIKWP White-Box AI Governance',
        'Policy makers',
        'AI reports are fluent but often lack visible evidence, trade-offs and purpose closure.',
        'DIKWP can function as a public audit grammar for AI governance.',
        'DIKWP Semantic Mathematics Overview; ProofLedger; UNESCO AI ethics recommendation.',
        'Could be overclaimed unless tied to pilot evidence.'
    )
    print(json.dumps(packet, indent=2, ensure_ascii=False))
